/************************************************************************/
/*                                                                      */
/*      SiI9134.c                                                       */
/*                                                                      */
/*      Copyright (c) Anchor Bay Technologies, Inc. 2003                */
/*      All Rights Reserved                                             */
/*                                                                      */
/************************************************************************/
#define     ASSERT_MODULE  MODULE_SII9134
//#define     SYSLOG         1

#include    <stdio.h>

#include    "Types.h"
#include    "SiI9134.h"
#include    "SiI9135.h"
#include    "Timer.h"
#include    "System.h"
#include    "IO.h"
#include    "IOdef.h"

/************************************************************************/
/*      Macros                                                          */
/************************************************************************/
#define  dSiI9134_CLR8(addr,mask)          sSiI9134_setData8(addr, sSiI9134_getData8(addr) & ~(mask))
#define  dSiI9134_SET8(addr,mask)          sSiI9134_setData8(addr, sSiI9134_getData8(addr) |  (mask))
#define  dSiI9134_PUT8(addr,mask,data)     sSiI9134_setData8(addr,(sSiI9134_getData8(addr) & ~(mask)) | ((data) & (mask)))
#define  dSiI9134_WR8(addr,data)           sSiI9134_setData8(addr, data)
#define  dSiI9134_GET8(addr,mask)          ( sSiI9134_getData8(addr) & (mask) )
#define  dSiI9134_RD8(addr)                ( sSiI9134_getData8(addr) )

#define  dSiI9134_CLR16(addr,mask)         sSiI9134_setData16(addr, sSiI9134_getData16(addr) & ~(mask))
#define  dSiI9134_SET16(addr,mask)         sSiI9134_setData16(addr, sSiI9134_getData16(addr) |  (mask))
#define  dSiI9134_PUT16(addr,mask,data)    sSiI9134_setData16(addr,(sSiI9134_getData16(addr) & ~(mask)) | ((data) & (mask)))
#define  dSiI9134_WR16(addr,data)          sSiI9134_setData16(addr, data)
#define  dSiI9134_GET16(addr,mask)         ( sSiI9134_getData16(addr) & (mask) )
#define  dSiI9134_RD16(addr)               ( sSiI9134_getData16(addr) )

/************************************************************************/
/*    Register Set                                                      */
/************************************************************************/

  /**********************************************************************************************/
  /*   Address range         Group       I2C addr        Purpose                                */
  /*   =============         =====       =========       =======                                */
  /*   0x00 - 0x0E           Base        0x70            Device ID & general programming        */
  /*   0x0F - 0x31           HDCP        0x70            HDCP authentication & other processes  */
  /*   0x32 - 0x6F           Video       0x70            Video detection & programming          */
  /*   0x70 - 0x7F           Interrupt   0x70            Interrupt processing                   */
  /*   0xEC - 0xFF           DDC         0x70            Mastering DDC bus                      */
  /*                                                                                            */
  /*   0x00 - 0x3D           Audio       0x78            Audio features and translations        */
  /*   0x3E - 0xFF           CEA-861B    0x78            Support for InfoFrame packets          */
  /*                                                                                            */
  /**********************************************************************************************/



/**********************/
/*  BANK 0 registers  */
/**********************/

   /*   Base registers   (0x00 - 0x0E) */

#define VENDOR_ID_ADDR             ((IO_Addr_t)0x000)
#define DEVICE_ID_ADDR             ((IO_Addr_t)0x002)
#define DEVICE_REV_ADDR            ((IO_Addr_t)0x004)
#define TX_SW_RESET_ADDR           ((IO_Addr_t)0x005)
#define TX_SYS_CNTRL_ADDR          ((IO_Addr_t)0x008)
#define TX_SYS_STATUS_ADDR         ((IO_Addr_t)0x009)
#define SYS_CTRL4_ADDR             ((IO_Addr_t)0x00C)


   /*   HDCP registers   (0x0F - 0x31) */

#define HDCP_CNTRL_ADDR            ((IO_Addr_t)0x00F)
#define BKSV_TXSIDE_ADDR           ((IO_Addr_t)0x010)  /* 5 bytes, Write only (WO), receiver KSV   */
#define AN_TXSIDE_ADDR             ((IO_Addr_t)0x015)  /* 8 bytes, Read/Write (RW), random value   */
#define AKSV_TXSIDE_ADDR           ((IO_Addr_t)0x01D)  /* 5 bytes, Read only (RO), transmitter KSV */
#define RI_TX_ADDR                 ((IO_Addr_t)0x022)  /* 2 bytes RO */
#define		BIT_ENC_EN						(0x01)
#define		BIT_RiREADY						(0x02)
#define		BIT_RI_STARTED					(0x01)					
#define		BIT_CP_RESET_N					(0x04)
#define		BIT_AN_STOP						(0x08)
#define		BIT_RX_REPEATER					(0x10)
#define		BIT_BKSV_ERROR					(0x20)
#define		BIT_ENC_ON						(0x40)

   /*   Video registers   (0x32 - 0x6F) */

#define DE_DLY_ADDR                ((IO_Addr_t)0x032)    //  Area to left of active display
#define DE_CNTRL_ADDR              ((IO_Addr_t)0x033)    //  Vsync, Hsync polarity
#define DE_TOP_ADDR                ((IO_Addr_t)0x034)    //  height of area above active display (12-bits)
#define DE_CNT_ADDR                ((IO_Addr_t)0x036)    //  Width of active display (pixels/dots)
#define DE_LIN_ADDR                ((IO_Addr_t)0x038)    //  Height of active display (lines)
#define H_RES_ADDR                 ((IO_Addr_t)0x03A)    //  Time between two Hsync active edges (pixels)
#define V_RES_ADDR                 ((IO_Addr_t)0x03C)    //  Time between two Vsync active edges (lines)

#define IADJUST_ADDR               ((IO_Addr_t)0x03E)    //  Interlace adjustment
#define POL_DETECT_ADDR            ((IO_Addr_t)0x03F)    //  Sync polarity detection
#define HBIT_2_SYNC_ADDR           ((IO_Addr_t)0x040)    //  Video Hbit to Hsync (10-bits)
#define FLD2_HS_OFST_ADDR          ((IO_Addr_t)0x042)    //  Field 2 Hysnc offset (12-bits)
#define HWIDTH_ADDR                ((IO_Addr_t)0x044)    //  Hsync Length (10-bits)
#define VBIT_TO_VSYNC_ADDR         ((IO_Addr_t)0x046)    //  Video Vbit to Vsync (6-bits)
#define VWIDTH_ADDR                ((IO_Addr_t)0x047)    //  Vsync Length (6-bits)
#define VID_CTRL_ADDR              ((IO_Addr_t)0x048)    //  Video control register
#define VID_ACEN                   ((IO_Addr_t)0x049)    //  Video Action Enable register
#define VID_MODE_ADDR              ((IO_Addr_t)0x04A)    //  Video mode register


   /*   Interrupt registers   (0x70 - 0x7F) */

   /*   Audio control registers   (0x - 0x7F) */


#define ECC_CTRL_ADDR              ((IO_Addr_t)0x04A)     //  Video mode register
#define HDMI_INT_ADDR						(0x71)
#define HDMI_INT1_ADDR						(0x71)	
#define HDMI_INT2_ADDR						(0x72)

#define HDMI_INT3_ADDR						(0x73)  // Ri error & DDC FIFO interrupts
#define     BIT_INT3_RI_ERR_3				(0x80)  // Ri reading was not done within one frame       , write "1" to clear.
#define     BIT_INT3_RI_ERR_2				(0x40)  // Ri did not changed between frames #127 and #0  , write "1" to clear.
#define     BIT_INT3_RI_ERR_1				(0x20)  // Ri and Ri� doesn't match during 2nd frame (0)  , write "1" to clear.
#define     BIT_INT3_RI_ERR_0				(0x10)  // Ri and Ri� doesn't match during 1st frame (127), write "1" to clear.
#define     BIT_INT3_DDC_CMD_DONE			(0x08)  // Asserted if DDC command is done                , write "1" to clear.
#define     BIT_INT3_DDC_FIFO_HALF			(0x04)  // Asserted if DDC FIFO is half full              , write "1" to clear.
#define     BIT_INT3_DDC_FIFO_FULL			(0x02)  // Asserted if DDC FIFO is full                   , write "1" to clear.
#define     BIT_INT3_DDC_FIFO_EMPTY			(0x01)  // Asserted if DDC FIFO is empty                  , write "1" to clear.

#define INT_CNTRL_ADDR						(0x79)
#define		BIT_INT_Ri_CHECK				(0x04)
#define		BIT_INT_HOT_PLUG				(0x40)
#define		BIT_BIPHASE_ERROR				(0x08)
#define		BIT_DROP_SAMPLE					(0x10)
#define		BIT_INT_VSYNC					(0x01)
#define		BIT_INT_FPIXCHANGE				(0x02)
#define		BIT_INT_KSV_READY				(0x80)

#define		MASK_RI_READING_MORE_ONE_FRAME  (0x80)
#define		MASK_RI_NOT_CHANGED             (0x40)
#define		MASK_RI_MISS_MATCH_FIRST_FRAME  (0x20)
#define		MASK_RI_MISS_MATCH_LAST_FRAME   (0x10)

#define		MASK_AUTO_RI                    (0xF0)
#define		MASK_AUTO_KSV_READY             (0x80)

   /*   DDC registers   (0xEC - 0xFF) */
   
#define MASTER_BASE                ((IO_Addr_t)0x0EC)
#define MDDC_MANUAL_ADDR           ((IO_Addr_t)0x0EC)
#define MDDC_SLAVE_ADDR            ((IO_Addr_t)0x0ED)
#define MDDC_SEGMENT_ADDR          ((IO_Addr_t)0x0EE)
#define MDDC_OFFSET_ADDR           ((IO_Addr_t)0x0EF)
#define MDDC_DIN_CNT_LSB_ADDR      ((IO_Addr_t)0x0F0)
#define MDDC_DIN_CNT_MSB_ADDR      ((IO_Addr_t)0x0F1)
#define MDDC_STATUS_ADDR           ((IO_Addr_t)0x0F2)
#define MDDC_COMMAND_ADDR          ((IO_Addr_t)0x0F3)

#define MDDC_FIFO_ADDR             ((IO_Addr_t)0x0F4)
#define MDDC_FIFO_CNT_ADDR         ((IO_Addr_t)0x0F5)

#define BIT_MDDC_ST_IN_PROGR       ((IO_Addr_t)0x010)
#define BIT_MDDC_ST_I2C_LOW        ((IO_Addr_t)0x040)
#define BIT_MDDC_ST_NO_ACK         ((IO_Addr_t)0x020)



/******************************************************************************************/
/*  BANK 1 registers (add 0x100 to address, to use 2nd Device Address defined in IOdef.c) */
/******************************************************************************************/
/*   Audio registers   (0x00 - 0x3D) */

// names are taken from the tables in the Prog. Ref document, appended w/ _ADDR
#define ACR_CTRL_ADDR              ((IO_Addr_t)0x101)
#define FREQ_SVAL_ADDR             ((IO_Addr_t)0x102)  // encodes MCLK ratio to Fs

#define N_SVAL1_ADDR               ((IO_Addr_t)0x103)  // bits 7:0
#define N_SVAL2_ADDR               ((IO_Addr_t)0x104)  // bits 15:8
#define N_SVAL3_ADDR               ((IO_Addr_t)0x105)  // bits 19:16 (upper 4 bits unused)

#define CTS_SVAL1_ADDR             ((IO_Addr_t)0x106)  // bits 7:0
#define CTS_SVAL2_ADDR             ((IO_Addr_t)0x107)  // bits 15:8
#define CTS_SVAL3_ADDR             ((IO_Addr_t)0x108)  // bits 19:16 (upper 4 bits unused)

#define CTS_HVAL1_ADDR             ((IO_Addr_t)0x109)  // bits 7:0
#define CTS_HVAL2_ADDR             ((IO_Addr_t)0x10a)  // bits 15:8
#define CTS_HVAL3_ADDR             ((IO_Addr_t)0x10b)  // bits 19:16 (upper 4 bits unused)

#define AUD_MODE_ADDR              ((IO_Addr_t)0x114)
#define	BIT_AUDIO_EN						(0x01)
#define	BIT_SPDIF_SELECT					(0x02)
#define	BIT_DSD_SELECT						(0x08)
#define	BIT_SPDIF_SAMPLE					(0x04)
#define	BIT_HBR_ON							(0x80)
#define	BIT_COMPRESSED						(0x10)

#define SPDIF_CTRL_ADDR            ((IO_Addr_t)0x115)
#define HW_SPDIF_FS_ADDR           ((IO_Addr_t)0x118)
#define SWAP_I2S_ADDR              ((IO_Addr_t)0x119)
#define I2S_IN_MAP_ADDR            ((IO_Addr_t)0x11c)
#define I2S_IN_CTRL_ADDR           ((IO_Addr_t)0x11d)
#define I2S_CHST1_ADDR             ((IO_Addr_t)0x11e)
#define I2S_CHST2_ADDR             ((IO_Addr_t)0x11f)
#define I2S_CHST3_ADDR             ((IO_Addr_t)0x120)
#define I2S_CHST4_ADDR             ((IO_Addr_t)0x121)
#define I2S_CHST5_ADDR             ((IO_Addr_t)0x122)

#define ASRC_ADDR                  ((IO_Addr_t)0x123)

#define HDMI_CTRL_ADDR             ((IO_Addr_t)0x12f)
#define AUDIO_TXSTAT_ADDR          ((IO_Addr_t)0x130)   // named "AUDO_TXSTAT" in Prog. Ref. doc

    /* Diagnostic Power Down Register */
#define DPD_ADDR                   ((IO_Addr_t)0x13d)


   /*   CEA-861B registers   (0x3E - 0xFF) */

// packet buffer control regs
#define PB_CTRL1_ADDR              ((IO_Addr_t)0x13e)
#define PB_CTRL2_ADDR              ((IO_Addr_t)0x13f)  // Before programming this reg, see SiI-PR-0003-0.90, Fig 12 (pg 77)
#define		BIT_AVI_REPEAT					(0x01)
#define		BIT_AVI_ENABLE					(0x02)
#define		BIT_SPD_REPEAT					(0x04)
#define		BIT_SPD_ENABLE					(0x08)
#define		BIT_AUD_REPEAT					(0x10)
#define		BIT_AUD_ENABLE					(0x20)
#define		BIT_MPEG_REPEAT					(0x40)
#define		BIT_MPEG_ENABLE					(0x80)
#define		BIT_GENERIC_REPEAT				(0x01)
#define		BIT_GENERIC_ENABLE				(0x02)
#define		BIT_CP_REPEAT					(0x04)
#define		BIT_CP_ENABLE					(0x08)


// AVI InfoFrame
#define AVI_TYPE_ADDR              ((IO_Addr_t)0x140)
#define AVI_VERS_ADDR              ((IO_Addr_t)0x141)
#define AVI_LEN_ADDR               ((IO_Addr_t)0x142)
#define AVI_CHSUM_ADDR             ((IO_Addr_t)0x143)
#define AVI_DBYTE1_ADDR            ((IO_Addr_t)0x144)
#define AVI_DBYTE2_ADDR            ((IO_Addr_t)0x145)
#define AVI_DBYTE3_ADDR            ((IO_Addr_t)0x146)
#define AVI_DBYTE4_ADDR            ((IO_Addr_t)0x147)
#define AVI_DBYTE5_ADDR            ((IO_Addr_t)0x148)
#define AVI_DBYTE6_ADDR            ((IO_Addr_t)0x149)
#define AVI_DBYTE7_ADDR            ((IO_Addr_t)0x14a)
#define AVI_DBYTE8_ADDR            ((IO_Addr_t)0x14b)
#define AVI_DBYTE9_ADDR            ((IO_Addr_t)0x14c)
#define AVI_DBYTE10_ADDR           ((IO_Addr_t)0x14d)
#define AVI_DBYTE11_ADDR           ((IO_Addr_t)0x14e)
#define AVI_DBYTE12_ADDR           ((IO_Addr_t)0x14f)
#define AVI_DBYTE13_ADDR           ((IO_Addr_t)0x150)
#define AVI_DBYTE14_ADDR           ((IO_Addr_t)0x151)
#define AVI_DBYTE15_ADDR           ((IO_Addr_t)0x152)

// SPD InfoFrame
#define SPD_TYPE_ADDR              ((IO_Addr_t)0x160)
#define SPD_VERS_ADDR              ((IO_Addr_t)0x161)
#define SPD_LEN_ADDR               ((IO_Addr_t)0x162)
#define SPD_CHSUM_ADDR             ((IO_Addr_t)0x163)
#define SPD_DBYTE1_ADDR            ((IO_Addr_t)0x164)
#define SPD_DBYTE2_ADDR            ((IO_Addr_t)0x165)
#define SPD_DBYTE3_ADDR            ((IO_Addr_t)0x166)
#define SPD_DBYTE4_ADDR            ((IO_Addr_t)0x167)
#define SPD_DBYTE5_ADDR            ((IO_Addr_t)0x168)
#define SPD_DBYTE6_ADDR            ((IO_Addr_t)0x169)
#define SPD_DBYTE7_ADDR            ((IO_Addr_t)0x16a)
#define SPD_DBYTE8_ADDR            ((IO_Addr_t)0x16b)
#define SPD_DBYTE9_ADDR            ((IO_Addr_t)0x16c)
#define SPD_DBYTE10_ADDR           ((IO_Addr_t)0x16d)
#define SPD_DBYTE11_ADDR           ((IO_Addr_t)0x16e)
#define SPD_DBYTE12_ADDR           ((IO_Addr_t)0x16f)
#define SPD_DBYTE13_ADDR           ((IO_Addr_t)0x170)
#define SPD_DBYTE14_ADDR           ((IO_Addr_t)0x171)
#define SPD_DBYTE15_ADDR           ((IO_Addr_t)0x172)
#define SPD_DBYTE16_ADDR           ((IO_Addr_t)0x173)
#define SPD_DBYTE17_ADDR           ((IO_Addr_t)0x174)
#define SPD_DBYTE18_ADDR           ((IO_Addr_t)0x175)
#define SPD_DBYTE19_ADDR           ((IO_Addr_t)0x176)
#define SPD_DBYTE20_ADDR           ((IO_Addr_t)0x177)
#define SPD_DBYTE21_ADDR           ((IO_Addr_t)0x178)
#define SPD_DBYTE22_ADDR           ((IO_Addr_t)0x179)
#define SPD_DBYTE23_ADDR           ((IO_Addr_t)0x17a)
#define SPD_DBYTE24_ADDR           ((IO_Addr_t)0x17b)
#define SPD_DBYTE25_ADDR           ((IO_Addr_t)0x17c)
#define SPD_DBYTE26_ADDR           ((IO_Addr_t)0x17d)
#define SPD_DBYTE27_ADDR           ((IO_Addr_t)0x17e)

// Audio InfoFrame
#define AUDIO_TYPE_ADDR            ((IO_Addr_t)0x180)
#define AUDIO_VERS_ADDR            ((IO_Addr_t)0x181)
#define AUDIO_LEN_ADDR             ((IO_Addr_t)0x182)
#define AUDIO_CHSUM_ADDR           ((IO_Addr_t)0x183)
#define AUDIO_DBYTE1_ADDR          ((IO_Addr_t)0x184)
#define AUDIO_DBYTE2_ADDR          ((IO_Addr_t)0x185)
#define AUDIO_DBYTE3_ADDR          ((IO_Addr_t)0x186)
#define AUDIO_DBYTE4_ADDR          ((IO_Addr_t)0x187)
#define AUDIO_DBYTE5_ADDR          ((IO_Addr_t)0x188)
#define AUDIO_DBYTE6_ADDR          ((IO_Addr_t)0x189)
#define AUDIO_DBYTE7_ADDR          ((IO_Addr_t)0x18a)
#define AUDIO_DBYTE8_ADDR          ((IO_Addr_t)0x18b)
#define AUDIO_DBYTE9_ADDR          ((IO_Addr_t)0x18c)
#define AUDIO_DBYTE10_ADDR         ((IO_Addr_t)0x18d)

// MPEG InfoFrame
#define MPEG_TYPE_ADDR             ((IO_Addr_t)0x1a0)
#define MPEG_VERS_ADDR             ((IO_Addr_t)0x1a1)
#define MPEG_LEN_ADDR              ((IO_Addr_t)0x1a2)
#define MPEG_CHSUM_ADDR            ((IO_Addr_t)0x1a3)
#define MPEG_DBYTE1_ADDR           ((IO_Addr_t)0x1a4)
#define MPEG_DBYTE2_ADDR           ((IO_Addr_t)0x1a5)
#define MPEG_DBYTE3_ADDR           ((IO_Addr_t)0x1a6)
#define MPEG_DBYTE4_ADDR           ((IO_Addr_t)0x1a7)
#define MPEG_DBYTE5_ADDR           ((IO_Addr_t)0x1a8)
#define MPEG_DBYTE6_ADDR           ((IO_Addr_t)0x1a9)
#define MPEG_DBYTE7_ADDR           ((IO_Addr_t)0x1aa)
#define MPEG_DBYTE8_ADDR           ((IO_Addr_t)0x1ab)
#define MPEG_DBYTE9_ADDR           ((IO_Addr_t)0x1ac)
#define MPEG_DBYTE10_ADDR          ((IO_Addr_t)0x1ad)
// note: Data Bytes 11-27 have regs in the 9134, but are not defined in CEA-861B
#define MPEG_DBYTE11_ADDR          ((IO_Addr_t)0x1ae)
#define MPEG_DBYTE12_ADDR          ((IO_Addr_t)0x1af)
#define MPEG_DBYTE13_ADDR          ((IO_Addr_t)0x1b0)
#define MPEG_DBYTE14_ADDR          ((IO_Addr_t)0x1b1)
#define MPEG_DBYTE15_ADDR          ((IO_Addr_t)0x1b2)
#define MPEG_DBYTE16_ADDR          ((IO_Addr_t)0x1b3)
#define MPEG_DBYTE17_ADDR          ((IO_Addr_t)0x1b4)
#define MPEG_DBYTE18_ADDR          ((IO_Addr_t)0x1b5)
#define MPEG_DBYTE19_ADDR          ((IO_Addr_t)0x1b6)
#define MPEG_DBYTE20_ADDR          ((IO_Addr_t)0x1b7)
#define MPEG_DBYTE21_ADDR          ((IO_Addr_t)0x1b8)
#define MPEG_DBYTE22_ADDR          ((IO_Addr_t)0x1b9)
#define MPEG_DBYTE23_ADDR          ((IO_Addr_t)0x1ba)
#define MPEG_DBYTE24_ADDR          ((IO_Addr_t)0x1bb)
#define MPEG_DBYTE25_ADDR          ((IO_Addr_t)0x1bc)
#define MPEG_DBYTE26_ADDR          ((IO_Addr_t)0x1bd)
#define MPEG_DBYTE27_ADDR          ((IO_Addr_t)0x1be)

// General Control Packet regs
#define CP_IF_ADDR                 ((IO_Addr_t)0x1DF)  // Contain Protect 1- byte Frame Info Frame

#define BIT_CP_AVI_MUTE_SET         0x01
#define BIT_CP_AVI_MUTE_CLEAR       0x10


   /******************************/
   /*  register bit definitions  */
   /******************************/

/* Bit Definitions for HDCP_CNTRL register */
#define ENC_ON_BIT                 0x40
#define BKSV_ERR_BIT               0x20
#define RX_RPTR_BIT                0x10
#define TX_ANSTOP_BIT              0x08
#define CP_RESETN_BIT              0x04
#define RI_RDY_BIT                 0x02
#define ENC_EN_BIT                 0x01

/* Bit Definitions for GEN_CTRL2_ADDR register */
#define RSVD_BIT                   0x80
#define M_SEL_MASK                 0x70
#define T_SEL_BIT                  0x08
#define R_SEN_BIT                  0x04
#define HTPLG_BIT                  0x02
#define MDI_BIT                    0x01

/* Bit Definitions for TX_SYS_CNTRL_ADDR  register  (0x08) */
#define BIT_TX_VSYNC_INPUT_STATUS  0x80
#define BIT_TX_VSYNC_EN            0x20
#define BIT_TX_HSYNC_EN            0x10
#define BIT_TX_BSEL_24_BIT         0x04
#define BIT_TX_CLOCK_RISING_EDGE   0x02
#define BIT_TX_PD_MODE             0x01

/* Bit Definitions for DE_CNTRL (0x33) register */
#define DE_GEN_ENABLE              0x40

/* Bit Definitions for TX_SW_RESET_ADDR (0x05) register */

#define BIT_TX_SW_RST              0x01
#define BIT_TX_FIFO_RST            0x02


   /******************************/
   /*  DDC Master Commands       */
   /******************************/

#define MASTER_CMD_ABORT           0x0f
#define MASTER_CMD_CLEAR_FIFO      0x09
#define MASTER_CMD_CLOCK_SCL       0x0a
#define MASTER_CMD_CUR_RD          0x00
#define MASTER_CMD_SEQ_RD          0x02
#define MASTER_CMD_ENH_RD          0x04
#define MASTER_CMD_SEQ_WR          0x06

#define MASTER_FIFO_WR_USE         0x01
#define MASTER_FIFO_RD_USE         0x02
#define MASTER_FIFO_EMPTY          0x04
#define MASTER_FIFO_FULL           0x08
#define MASTER_DDC_BUSY            0x10
#define MASTER_DDC_NOACK           0x20
#define MASTER_DDC_STUCK           0x40
#define MASTER_DDC_RSVD            0x80


#define MDDCCommand( CMD )         dSiI9134_WR8(MDDC_COMMAND_ADDR, CMD)

//-----------------------------------------------------------------------------
// These defines are used for Deep Color  (Video Path)
//-----------------------------------------------------------------------------
enum SiI_DeepColor {
    SiI_DeepColor_24bit = 0x00,
    SiI_DeepColor_30bit = 0x01,
    SiI_DeepColor_36bit = 0x02,
    SiI_DeepColor_Off   = 0xFF
};

enum SiI_AuxVidBusInfo {

    SiI_RisingVideoClockEdge = 0x01,
    SiI_ClippingVideo = 0x02,
    SiI_CopmpressingVideo = 0x04

};

enum SiI_SF {
    SiI_SF_32kHz = 0x01,
    SiI_SF_44kHz = 0x02,
    SiI_SF_48kHz = 0x03,
    SiI_SF_88kHz = 0x04,
    SiI_SF_96kHz = 0x05,
    SiI_SF_176kHz = 0x06,
    SiI_SF_192kHz = 0x07
};

#define TX_SWRST_ADDR						(0x05)
#define TX_SYS_CTRL1_ADDR					(0x08)
#define TX_STAT_ADDR						(0x09)
#define TX_SYS_CTRL4_ADDR					(0x0C)
#define		BIT_TX_PD						(0x01)
#define		BIT_BSEL24BITS					(0x04)
#define		BIT_HPD_PIN						(0x02)
#define     P_STABLE_BIT		            (0x01)


#define VID_ACEN_ADDR						(0x49)
#define     BIT_VID_ACEN_CLIP_CS_ID			(0x10)  // Color Space on the link: RGB (0) / YCbCr (1)
#define     BIT_VID_ACEN_RANGE_CLIP			(0x08)  // enable(1) / disable(0-default) Range Clip from 16 to 235(RGB and Y)/240(C)
#define     BIT_VID_ACEN_RGB2YCBCR			(0x04)  // enable(1) / disable(0-default) RGB to YCbCr color-space converter
#define     BIT_VID_ACEN_RANGE_COMP			(0x02)  // enable(1) / disable(0-default)
#define     BIT_VID_ACEN_DWN_SAMPLE			(0x01)  // enable(1) / disable(0-default) 4:4:4 to 4:2:2 chroma down sampler
#define		VID_ACEN_DEEP_COLOR_CLR			(0x3F)

#define TX_VID_MODE_ADDR					(0x4A)
#define		BIT_TX_SYNC_EXTR				(0x01)
#define		BIT_TX_DEMUX_YC					(0x02)
#define		BIT_TX_422to444					(0x04)  // Upsampling
#define		BIT_TX_CSC						(0x08)
#define		BIT_TX_16_235_RANGE				(0x10)  // Expand range
#define		BIT_TX_DITHER					(0x20)

#define AUDP_TXCTRL_ADDR					(0x12F)
#define		BIT_DEEPCOLOR_EN				(0x40)
#define		BIT_TXHDMI_MODE					(0x01)
#define		BIT_LAYOUT						(0x02)
#define		BIT_LAYOUT1						(0x02)

#define TX_TMDS_CCTRL_ADDR					(0x80)
#define TX_TMDS_CTRL_ADDR					(0x82)
#define TX_TMDS_CTRL2_ADDR					(0x83)
#define TX_TMDS_CTRL3_ADDR					(0x84)
#define TX_TMDS_CTRL4_ADDR					(0x85)


#define TMDS_SETUP_FAILED		1
#define TMDS_SETUP_PASSED		0

#define CLR_BITS_7_6_5			0x3F
#define CLR_BITS_5_4_3			0xC7
#define BIT_DITHER_EN			0x20

#define siiIsTClockStable()  ( sSiI9134_getData8( TX_STAT_ADDR ) & 0x01 )

/************************************************************************/
/*      Local type definitions                                          */
/************************************************************************/
typedef struct MDDC_s
{
    UInt8   DevAddr;
    UInt8   Segment;
    UInt8   SubAddr;
    UInt8   NBytesLSB;
    UInt8   NBytesMSB;
} MDDC_t;

typedef enum { x0_5 = 0x00, x1 = 0x20, x2 = 0x40, x4 = 0x60 } TCLK_SEL; // Move this into SiITXAPIDefs.h when TCLK_SEL is part of the API.
typedef enum RANGE_t { blue, yellow, orange } RANGE;

/************************************************************************/
/*      Static Functions                                                */
/************************************************************************/
static void     sSiI9134_setData8( IO_Addr_t Addr, UInt8 Data );
static UInt8    sSiI9134_getData8( IO_Addr_t Addr );
static void     sSiI9134_setData16( IO_Addr_t Addr, UInt16 Data );
static UInt16   sSiI9134_getData16( IO_Addr_t Addr );
static void     sSiI9134_setBlock( IO_Addr_t Addr, UInt8 Size, UInt8* pData );
static void     sSiI9134_getBlock( IO_Addr_t Addr, UInt8 Size, UInt8* pData );
static void     sSiI9134_Dump( void );

static  void    sSiI9134_Set_N_Sval( UInt32 value );
static  rval_t  sSiI9134_setBlockMDDC( MDDC_t* pMDDC, UInt8* pData );
static  rval_t  sSiI9134_getBlockMDDC( MDDC_t* pMDDC, UInt8* pData );
static  void    sSetDeepColor ( UInt8 bDeepColor );
static  UInt8   sSiI_TMDS_setup(UInt8 bVMode);
static  void    sSiI_Mpll_setup(UInt8 MpllSet);
static  void    sSiI_FApost_setup(UInt8 RangeSet, int idclk_freq, UInt8 bpp);
static  void    sAssertHDMITX_SWReset(UInt8 SoftReset);
static  void    sReleaseHDMITX_SWReset( UInt8 SoftReset );
static  void    sSW_ResetHDMITX(void);
static  Bool    sWaitNewVSync( void );
static  void    sSendCP_Packet(UInt8 On);
//static  void    sSetEncryption(UInt8 OnOff);
//static  void    sTXAudio(UInt8 On);
static  void    sSiI9134_UpdateColorSpaceConversion( void );
static Bool     sSiI9134_isHotPlug( void );
static Bool     sSiI9134_isHotPlugEvent( void );
static void     sSiI9134_HPHandler( void );

/************************************************************************/
/*      UFD Registration                                                */
/************************************************************************/
#include    "UFD.h"
static UFD_CmdTbl_t sUFDCmdTbl[] =
{
UFD_HDR( "SiI9134",   "Driver for SII9134" ),

UFD_RC1( "Gdev",      I08,          SiI9134_setDevice,            SiI9134_getDevice,           "Device Select (0=Dev1, 1=Dev2, etc.)"    ),
UFD_RC2( "G8",        U08,U16,     sSiI9134_setData8,            sSiI9134_getData8,            "SiI9134   [<a9>]  <-> <d8>"    ),
UFD_RC2( "G16",       U16,U16,     sSiI9134_setData16,           sSiI9134_getData16,           "SiI9134   [<a9>]  <-> <d16>"   ),
UFD_RC1( "Gdmp",      VOI,         sSiI9134_Dump,                NULL,                           "SiI9134 Register dump"         ),

UFD_END()
};

/************************************************************************/
/*      Static Variables                                                */
/************************************************************************/
static Timer_Stat_t     sHPHandlerStat      = { "SiI9134", 5, (Timer_Func_t)sSiI9134_HPHandler };
static Inst_t           sHPHandlerInst      = (Inst_t)0;

static Inst_t           sIOInst             = (Inst_t)0;
static UInt32           sACR_N_Sval         = 6144;
static Aud_SmpRate_t    sAudioSampleRate    = eAud_SmpRate_NI;

static SiI9134_ClrSpc_t sInpClrSpc          = eSiI9134_ClrSpc_RGB444;
static SiI9134_YUVMod_t sInpYUVMod          = eSiI9134_YUVMod_601;
static SiI9134_ClrSpc_t sOutClrSpc          = eSiI9134_ClrSpc_RGB444;
static SiI9134_YUVMod_t sOutYUVMod          = eSiI9134_YUVMod_601;

static IO_Dev_t         sDevTot             = 0;

static CBFunc_Stat_t    sHotPlugCBStat      = { "SiI9134", 2 };
static Inst_t           sHotPlugCBInst[2]   = { (Inst_t)0, (Inst_t)0 };
                                                     
/************************************************************************/
/*      Application Interface                                           */
/************************************************************************/
GLOBAL rval_t SiI9134_Init( void )
{
    IO_Dev_t DevTot = 0;

    /* Initialize SiI9134 I/O layer */
    sDevTot = IO_Open(&sIOInst, &gIOdef_Stat_SiI9134);

    DevTot = sDevTot;
    while( DevTot-- )
    {
        IO_setDevice(sIOInst, DevTot);

        /* Set SiI9134 PD bit */
        dSiI9134_SET8(TX_SYS_CNTRL_ADDR, 0x01);

        /* Clock on rising edge */
        dSiI9134_SET8(TX_SYS_CNTRL_ADDR, 0x02);

        /* Open Hot-Plug Call-Back pointer List */
        CBFunc_Open(&sHotPlugCBInst[DevTot], &sHotPlugCBStat);
    }

    /* Install Hot-Plug Timer */
    Timer_Open(&sHPHandlerInst, &sHPHandlerStat);
    assert(sHPHandlerInst);
    Timer_Start(sHPHandlerInst);

    UFD_AddCommandTable(sUFDCmdTbl);
    return 0;
}

/*----------------------------------------------------------------------*/
/*  CallBack Registration handlers                                      */
/*----------------------------------------------------------------------*/
GLOBAL void SiI9134_setHotPlugCBFunc( IO_Dev_t Dev, CBFunc_Func_t Func )
{
    CBFunc_Register(sHotPlugCBInst[Dev], Func);
}

GLOBAL void SiI9134_clrHotPlugCBFunc( IO_Dev_t Dev, CBFunc_Func_t Func )
{
    CBFunc_UnRegister(sHotPlugCBInst[Dev], Func);
}

GLOBAL void SiI9134_setDevice( IO_Dev_t Dev )
{
    IO_setDevice(sIOInst, Dev);
    RETURN_VOID(RETVAL);
}

GLOBAL IO_Dev_t SiI9134_getDevice( void )
{
    return IO_getDevice(sIOInst);
}

GLOBAL void SiI9134_setData8( IO_Addr_t Addr, UInt8 Data )
{
    sSiI9134_setData8(Addr,Data);
}

GLOBAL UInt8 SiI9134_getData8( IO_Addr_t Addr )
{
    return sSiI9134_getData8(Addr);
}

GLOBAL Bool SiI9134_isHotPlug( void )
{
    return sSiI9134_isHotPlug();
}

GLOBAL void SiI9134_setSleepMode( Bool isTrue )
{
    if( isTrue )
    {
        dSiI9134_CLR8(0x13D, 0x01);
        Timer_Stop(sHPHandlerInst);
    }
    else
    {
        dSiI9134_SET8(0x13D, 0x01);
        Timer_Start(sHPHandlerInst);
    }
}

GLOBAL Bool SiI9134_isSleepMode( void )
{
    return (!dSiI9134_GET8(0x13D, 0x01)) ? (TRUE) : (FALSE);
}

GLOBAL void SiI9134_HDMImode( Bool mode )
{
    UInt8 DataByte;

    DataByte = sSiI9134_getData8(HDMI_CTRL_ADDR);
    
    if(mode) sSiI9134_setData8(HDMI_CTRL_ADDR, DataByte | 1);
    else     sSiI9134_setData8(HDMI_CTRL_ADDR, DataByte & (~1));
}

GLOBAL rval_t SiI9134_InitAudio( void )
{
    // Audio Initialization

    sSiI9134_setData8( AUD_MODE_ADDR,    0x11); // enable I2S ch0, set AUD_EN bit
    sSiI9134_setData8( I2S_IN_CTRL_ADDR, 0x40); // right-justify, shift 1st bit

    return 0;
}

GLOBAL void SiI9134_setResetCP( Bool isTrue )
{
    if( isTrue )
    {
        dSiI9134_CLR8(HDCP_CNTRL_ADDR, CP_RESETN_BIT);
    }
    else
    {
        dSiI9134_SET8(HDCP_CNTRL_ADDR, CP_RESETN_BIT);
    }
}

GLOBAL Bool SiI9134_isResetCP( void )
{
    return (dSiI9134_GET8(HDCP_CNTRL_ADDR, CP_RESETN_BIT)) ? (FALSE) : (TRUE);
}

// SiI9134_SetAudioSampleRate
//  This function is required so that the HDMI transmitter will use the proper N and CTS values
//  when transmitting audio clock reconstruction parameters.
GLOBAL rval_t SiI9134_SetAudioSampleRate( Aud_SmpRate_t Rate )
{
    LOG_FUNC_NAME("SiI9134_SetAudioSampleRate")

    UInt32 Nval;
    UInt8  FScode;
    sAudioSampleRate = Rate ;
    switch( sAudioSampleRate )
    {   // N values below taken from recommended values in HDMI spec (section 7.2.3)
        case eAud_SmpRate_32k:
            LOG_TXT1(("Sample Rate is 32k"));
            Nval = 4096;
            FScode = 0x03;
            break;
        case eAud_SmpRate_44k1:
            LOG_TXT1(("Sample Rate is 44k1"));
            Nval = 6272;
            FScode = 0x00;
            break;
        case eAud_SmpRate_48k:
            LOG_TXT1(("Sample Rate is 48k"));
            Nval = 6144;
            FScode = 0x02;
            break;
        case eAud_SmpRate_88k2:
            LOG_TXT1(("Sample Rate is 88k2"));
            Nval = 12544;
            FScode = 0x08;
            break;
        case eAud_SmpRate_96k:
            LOG_TXT1(("Sample Rate is 96k"));
            Nval = 12288;
            FScode = 0x0a;
            break;
        case eAud_SmpRate_176k4:
            LOG_TXT1(("Sample Rate is 176k4"));
            Nval = 25088;
            FScode = 0x0c;
            break;
        case eAud_SmpRate_192k:
            LOG_TXT1(("Sample Rate is 192k"));
            Nval = 24576;
            FScode = 0x0e;
            break;
        default:
            // not sure what to use... use 48k value for now
            LOG_TXT1(("Sample Rate is NI"));
            Nval = 6144;
            FScode = 0x01; // "not indicated"
            break;
    }

    // now save the N value to the registers
    sSiI9134_Set_N_Sval( Nval );

    // write FScode to CHST4 register (leave CLK_ACCUR bits zero)
    sSiI9134_setData8( I2S_CHST4_ADDR, FScode);

    return 0;
}

GLOBAL rval_t SiI9134_AudioHDMIPacketEnable( Bool isTrue )
{
    LOG_FUNC_NAME("SiI9134_AudioHDMIPacketEnable")
    UInt8 RegVal;
    RegVal = sSiI9134_getData8( PB_CTRL1_ADDR );
    //need to first send enable, then send repeat when isTrue is TRUE
    if ( isTrue )   
    {
        LOG_TXT1(("HDMI packets are enabled"));
        sSiI9134_setData8( PB_CTRL1_ADDR,  RegVal | 0x20 );
        sSiI9134_setData8( PB_CTRL1_ADDR,  RegVal | 0x10 );
    }
    else            
    {
        sSiI9134_setData8( PB_CTRL1_ADDR,  RegVal & 0xCF );
        LOG_TXT1(("HDMI packets are disabled"));
    }

    return 0;
}

GLOBAL rval_t SiI9134_AudioTXenable( void )
{
    LOG_FUNC_NAME("SiI9134_AudioTXenable")
    UInt8 RegVal;

    LOG_TXT1(("Audio TX enabled"));
    RegVal = sSiI9134_getData8( AUD_MODE_ADDR );
    sSiI9134_setData8( AUD_MODE_ADDR,  RegVal | 0x01 );
    return 0;
}

GLOBAL rval_t SiI9134_AudioTXdisable( void )
{
    LOG_FUNC_NAME("SiI9134_AudioTXdisable")
    UInt8 RegVal;

    LOG_TXT1(("Audio TX disabled"));
    RegVal = sSiI9134_getData8( AUD_MODE_ADDR );
    sSiI9134_setData8( AUD_MODE_ADDR,  RegVal & 0xfe );
    return 0;
}

GLOBAL rval_t SiI9134_Set_MCLK_ratio( Aud_MCLKratio_t Ratio )
{
    UInt8 temp;
    switch( Ratio )
    {
        case eAud_MCLKratio_128Fs:
            temp = 0x00;
            break;
        case eAud_MCLKratio_192Fs:
            temp = 0x07;
            break;
        case eAud_MCLKratio_256Fs:
            temp = 0x01;
            break;
        case eAud_MCLKratio_384Fs:
            temp = 0x02;
            break;
        case eAud_MCLKratio_512Fs:
            temp = 0x03;
            break;
        default:
            return -1;
    }

    sSiI9134_setData8( FREQ_SVAL_ADDR, temp );
    return 0;
}

/********************************************************************/
/*                                                                  */
/*  The 9134 has a "Master DDC" mode, which allows the 9134 to      */
/*  access a slave device on a DDC-I2C bus.                         */
/*                                                                  */
/*  Usually this is a receiver chip in a remote display (sink),     */
/*  which communicates over the DVI cable's DDC bus.                */
/*                                                                  */
/*  The 9134's Master DDC bus access is typically used to either:   */
/*     (1) read the EDID of the remote device, or                   */
/*     (2) data exchange during HDCP authentication                 */
/*                                                                  */
/********************************************************************/
GLOBAL rval_t SiI9134_WriteBlockMDDC( UInt8 DevAddr, UInt8 SubAddr, UInt16 Size, UInt8* pData )
{
    MDDC_t MDDC;

    MDDC.DevAddr   = DevAddr;
    MDDC.Segment   = 0;
    MDDC.SubAddr   = SubAddr;
    MDDC.NBytesLSB = (UInt8)(Size&0xFF);
    MDDC.NBytesMSB = (UInt8)((Size>>8)&0xFF);

    sSiI9134_setBlockMDDC(&MDDC, pData);
    return 0;
}

GLOBAL rval_t SiI9134_ReadBlockMDDC( UInt8 DevAddr, UInt8 SubAddr, UInt16 Size, UInt8* pData )
{
    MDDC_t MDDC;

    MDDC.DevAddr   = DevAddr;
    MDDC.Segment   = 0;
    MDDC.SubAddr   = SubAddr;
    MDDC.NBytesLSB = (UInt8)(Size&0xFF);
    MDDC.NBytesMSB = (UInt8)((Size>>8)&0xFF);

    sSiI9134_getBlockMDDC(&MDDC, pData);
    return 0;
}

GLOBAL rval_t SiI9134_WriteBlockEEDID( UInt8 Block, UInt8 Addr, UInt8 Size, void* pData )
{
    MDDC_t MDDC;

    assert(2>Block);
    assert(128>Addr);
    assert(128>=Size);
    assert((128-Addr)>=Size);

    MDDC.DevAddr   = 0xA0;
    MDDC.Segment   = Block>>1;
    MDDC.SubAddr   = (Block%2) ? (0x80+Addr) : (Addr);
    MDDC.NBytesLSB = Size;
    MDDC.NBytesMSB = 0;

    sSiI9134_setBlockMDDC(&MDDC, pData);
    return 0;
}

GLOBAL rval_t SiI9134_ReadBlockEEDID( UInt8 Block, UInt8 Addr, UInt8 Size, void* pData )
{
    MDDC_t MDDC;

    assert(128>Block);
    assert(128>Addr);
    assert(128>=Size);
    assert((128-Addr)>=Size);

    MDDC.DevAddr   = 0xA0;
    MDDC.Segment   = Block>>1;
    MDDC.SubAddr   = (Block%2) ? (0x80+Addr) : (Addr);
    MDDC.NBytesLSB = Size;
    MDDC.NBytesMSB = 0;

    sSiI9134_getBlockMDDC(&MDDC, pData);
    return 0;
}

GLOBAL void SiI9134_Set_AV_MuteMode( Bool isTrue )
{
    if ( isTrue )
    {
        /* AV Mute mode = ON */
        dSiI9134_PUT8(0x1DF, 0x11, 0x01);
    }
    else
    {
        /* AV Mute mode = OFF */
        dSiI9134_PUT8(0x1DF, 0x11, 0x10);
    }
    return;
}

GLOBAL void SiI9134_setRepeaterBit( Bool isTrue )
{
    if( isTrue )
    {
        dSiI9134_SET8(0x00F, 0x10);
    }
    else
    {
        dSiI9134_CLR8(0x00F, 0x10);
    }
}

GLOBAL void SiI9134_EnableEncryption( void )
{
    dSiI9134_SET8(0x00F, 0x01);
}

GLOBAL Bool SiI9134_isEncryption( void )
{
    return (dSiI9134_GET8(0x00F, 0x40)) ? (TRUE) : (FALSE);
}

GLOBAL void SiI9134_getVectorAN( UInt8* pAN )
{
    /* Read AN Value */
    sSiI9134_getBlock(0x015, 8, pAN);
}

GLOBAL void SiI9134_getVectorAKSV( UInt8* pAKSV )
{
    /* Read AKSV Value */
    sSiI9134_getBlock(0x01D, 5, pAKSV);
}

GLOBAL void SiI9134_setVectorBKSV( UInt8* pBKSV )
{
    /* Read AKSV Value */
    sSiI9134_setBlock(0x010, 5, pBKSV);
}

GLOBAL Bool SiI9134_isBKSVformatError( void )
{
    return (dSiI9134_GET8(0x00F, 0x20)) ? (TRUE) : (FALSE);
}

GLOBAL Bool SiI9134_isRiReady( void )
{
    return (dSiI9134_GET8(0x00F, 0x02)) ? (TRUE) : (FALSE);
}

GLOBAL UInt16 SiI9134_getLocalRi( void )
{
    return dSiI9134_RD16(0x022);
}

GLOBAL Bool SiI9134_isRSen( void )
{
   return (dSiI9134_GET8(0x009, 0x04)) ? (TRUE) : (FALSE);
}

GLOBAL void SiI9134_StartAN( void )
{
    dSiI9134_CLR8(0x00F, 0x08);
}

GLOBAL void SiI9134_StopAN( void )
{
    dSiI9134_SET8(0x00F, 0x08);
}

GLOBAL void SiI9134_setCHST1( UInt8 data )
{
    dSiI9134_WR8( I2S_CHST1_ADDR, data );
}

GLOBAL void SiI9134_setCHST2( UInt8 data )
{
    dSiI9134_WR8( I2S_CHST2_ADDR, data );
}

GLOBAL void SiI9134_setCHST3( UInt8 data )
{
    dSiI9134_WR8( I2S_CHST3_ADDR, data );
}

GLOBAL void SiI9134_setCHST4( UInt8 data )
{
    /* the 4 lsbs are the fs and they are set in set sample rate */
    dSiI9134_PUT8( I2S_CHST4_ADDR, 0xf0, data );
}

GLOBAL void SiI9134_setCHST5( UInt8 data )
{
    dSiI9134_WR8( I2S_CHST5_ADDR, data );
}

GLOBAL UInt8  SiI9134_getCHST1( void )
{
    return( dSiI9134_RD8( I2S_CHST1_ADDR ) );
}

GLOBAL UInt8  SiI9134_getCHST2( void )
{
    return( dSiI9134_RD8( I2S_CHST2_ADDR ) );
}

GLOBAL UInt8  SiI9134_getCHST3( void )
{
    return( dSiI9134_RD8( I2S_CHST3_ADDR ) );
}

GLOBAL UInt8  SiI9134_getCHST4( void )
{
    return( dSiI9134_RD8( I2S_CHST4_ADDR ) );
}

GLOBAL UInt8  SiI9134_getCHST5( void )
{
    return( dSiI9134_RD8( I2S_CHST5_ADDR ) );
}


GLOBAL void SiI9134_setMultiChannelAud( Bool isTrue )
{
    LOG_FUNC_NAME("SiI9134_setMultiChannelAud")
    if ( isTrue )
    {
        /* enable i2s inputs */
        dSiI9134_SET8( HDMI_CTRL_ADDR, 1<<1);
        LOG_TXT1(("Enabling i2s"));
    }
    else
    {
        /* disable i2s inputs */
        dSiI9134_CLR8( HDMI_CTRL_ADDR, 1<<1);
        LOG_TXT1(("Disbling i2s"));
    }
    
}

GLOBAL Bool  SiI9134_getMultiChannelAud( void )
{
    return( (sSiI9134_getData8( HDMI_CTRL_ADDR )>>1) & 0x01 );
}

GLOBAL void SiI9134_setHBRAud( Bool isTrue )
{
    LOG_FUNC_NAME("SiI9134_setHBRAud")
    if ( isTrue )
    {
        /* enable HBR input */
        dSiI9134_SET8( I2S_IN_CTRL_ADDR, 1<<7);
        LOG_TXT1(("Enabling HBR"));
    }
    else
    {
        /* disable HBR input */
        dSiI9134_CLR8( I2S_IN_CTRL_ADDR, 1<<7);
        LOG_TXT1(("Disbling HBR"));
    }
    
}

GLOBAL Bool  SiI9134_getHBRAud( void )
{
    return( (sSiI9134_getData8( I2S_IN_CTRL_ADDR )>>7) & 0x01 );
}

GLOBAL void SiI9134_setI2S( Bool isTrue )
{            
    LOG_FUNC_NAME("SiI9134_setI2S")
    if ( isTrue )
    {
        /* enable i2s inputs */
        dSiI9134_SET8( 0x114, 0xf0);
        LOG_TXT1(("Enabling i2s"));
    }
    else
    {
        /* disable i2s inputs */
        dSiI9134_CLR8( 0x114, 0xf0);
        LOG_TXT1(("Disbling i2s"));
    }
}

GLOBAL void SiI9134_setDeepColor ( UInt8 bDeepColor )
{
    LOG_FUNC_NAME("SiI9134_setDeepColor")
    UInt8            InfCtrl1, InfCtrl2;

    sSendCP_Packet(TRUE);
    sWaitNewVSync();
    sWaitNewVSync();

    InfCtrl1 = sSiI9134_getData8(PB_CTRL1_ADDR);// save packet buffer control regs
    InfCtrl2 = sSiI9134_getData8(PB_CTRL2_ADDR);
   
    sSiI9134_setData8(PB_CTRL1_ADDR, 0);        // Disable sending all control packets
    sSiI9134_setData8(PB_CTRL2_ADDR, 0xC0);

    
    sSetDeepColor(bDeepColor);
    sSiI_TMDS_setup(0);
    
    {
        Timer_TO_t TimeOut = 0;

        Timer_setTimeOut(&TimeOut, 2); 
        while( !(sSiI9134_getData8(TX_STAT_ADDR) & P_STABLE_BIT) ) // Wait for the clock to be stable
        {
            assert(!Timer_isTimeOut(TimeOut));       // ST: Should never happen
        }
    }
    
    sSW_ResetHDMITX();                               // Reset internal state machines and allow TCLK to Rx to stabilize

    sWaitNewVSync();
    sWaitNewVSync();                                 // assure packet has been received

    sSiI9134_setData8(PB_CTRL1_ADDR, InfCtrl1);   // Retrieve packet buffer control regs
    sSiI9134_setData8(PB_CTRL2_ADDR, InfCtrl2);

    sSendCP_Packet(FALSE);                           // Restore packet sending
}

GLOBAL void SiI9134_setInpColorSpace( SiI9134_ClrSpc_t Value )
{
    sInpClrSpc = Value;
    sSiI9134_UpdateColorSpaceConversion();
}

GLOBAL SiI9134_ClrSpc_t SiI9134_getInpColorSpace( void )
{
    return sInpClrSpc;
}

GLOBAL void SiI9134_setInpYUVMode( SiI9134_YUVMod_t Value )
{
    sInpYUVMod = Value;
    sSiI9134_UpdateColorSpaceConversion();
}

GLOBAL SiI9134_YUVMod_t SiI9134_getInpYUVMode( void )
{
    return sInpYUVMod;
}

GLOBAL void SiI9134_setOutColorSpace( SiI9134_ClrSpc_t Value )
{
    sOutClrSpc = Value;
    sSiI9134_UpdateColorSpaceConversion();
}

GLOBAL SiI9134_ClrSpc_t SiI9134_getOutColorSpace( void )
{
    return sOutClrSpc;
}

GLOBAL void SiI9134_setOutYUVMode( SiI9134_YUVMod_t Value )
{
    sOutYUVMod = Value;
    sSiI9134_UpdateColorSpaceConversion();
}

GLOBAL SiI9134_YUVMod_t SiI9134_getOutYUVMode( void )
{
    /* 601/709 cross conversion is not supported */
    if( (eSiI9134_ClrSpc_RGB444 != sInpClrSpc) && (eSiI9134_ClrSpc_RGB444 != sOutClrSpc) )
        return sInpYUVMod;
    else
        return sOutYUVMod;
}

GLOBAL rval_t SiI9134_UpdateInfoFrameRegs( InfoFrame_t *p )
{
    UInt16 Addr, i;
    UInt8  len;
    
    if(p == NULL) return -1;

    switch( p->Type )
    {
        case INFOFRAME_TYPE_AVI:
            Addr = AVI_TYPE_ADDR;
            len  = AVI_MAX_LEN;
            break;
        case INFOFRAME_TYPE_SPD:
            Addr = SPD_TYPE_ADDR;
            len  = SPD_MAX_LEN;
            break;
        case INFOFRAME_TYPE_AUDIO:
            Addr = AUDIO_TYPE_ADDR;
            len  = AUD_MAX_LEN;
            break;
        case INFOFRAME_TYPE_MPEG:
            Addr = MPEG_TYPE_ADDR;
            len  = MPEG_MAX_LEN;
            break;
        default:
            return -1;
    }
    
    
    /* copying infoframe to hardware registers */
    
    sSiI9134_setData8(Addr++, p->Type );
    sSiI9134_setData8(Addr++, p->Version );
    sSiI9134_setData8(Addr++, p->Length );
    sSiI9134_setData8(Addr++, p->Checksum );  // not checked here for validity!

    if(p->Length > len) p->Length = len;
        
    for( i=0; i<p->Length; ++i )
        sSiI9134_setData8( Addr++, p->Data[i] );

    return 0;
}

GLOBAL rval_t SiI9134_DisableInfoFrameTx( InfoFrameType_t Type )
{
    UInt8 mask, current;

    switch( Type )
    {
        case INFOFRAME_TYPE_AVI:
            mask = 0xfc;
            break;
        case INFOFRAME_TYPE_SPD:
            mask = 0xf3;
            break;
        case INFOFRAME_TYPE_AUDIO:
            mask = 0xcf;
            break;
        case INFOFRAME_TYPE_MPEG:
            mask = 0x3f;
            break;
        default:
            return -1;
    }
    
    current = sSiI9134_getData8(PB_CTRL1_ADDR);
    sSiI9134_setData8(PB_CTRL1_ADDR, current & mask );
    return 0;
}

GLOBAL rval_t SiI9134_SendInfoFrameOnce( InfoFrameType_t Type )
{
    UInt8 clrmask, setmask, current;

    LOG_TEXT(("Type = %02x", Type ));
    switch( Type )
    {
        case INFOFRAME_TYPE_AVI:
            clrmask = 0xfc;
            setmask = 0x02;
            break;
        case INFOFRAME_TYPE_SPD:
            clrmask = 0xf3;
            setmask = 0x08;
            break;
        case INFOFRAME_TYPE_AUDIO:
            clrmask = 0xcf;
            setmask = 0x20;
            break;
        case INFOFRAME_TYPE_MPEG:
            clrmask = 0x3f;
            setmask = 0x80;
            break;
        default:
            return -1;
    }
    // first clear EN and RPT bits, then set requested EN bit
    current = sSiI9134_getData8(PB_CTRL1_ADDR);
    current &= clrmask;
    sSiI9134_setData8(PB_CTRL1_ADDR, current);
    sSiI9134_setData8(PB_CTRL1_ADDR, current | setmask );
    return 0;
}

GLOBAL rval_t SiI9134_SendInfoFrameRepeat( InfoFrameType_t Type )
{
    UInt8 mask, current;

    LOG_TEXT(("Type = %02x", Type ));
    switch( Type )
    {
        case INFOFRAME_TYPE_AVI:
            mask = 0x03;
            break;
        case INFOFRAME_TYPE_SPD:
            mask = 0x0c;
            break;
        case INFOFRAME_TYPE_AUDIO:
            mask = 0x30;
            break;
        case INFOFRAME_TYPE_MPEG:
            mask = 0xc0;
            break;
        default:
            return -1;
    }
    // first clear EN and RPT bits, then set requested EN+RPT bits
    current = sSiI9134_getData8(PB_CTRL1_ADDR);
    sSiI9134_setData8(PB_CTRL1_ADDR, current & ~mask );
    sSiI9134_setData8(PB_CTRL1_ADDR, current | mask );
    return 0;
}

/************************************************************************/
/*      Local Functions                                                 */
/************************************************************************/
static void sSiI9134_setData8( IO_Addr_t Addr, UInt8 Data )
{
    IO_setData(sIOInst, Addr, 1, &Data);
    RETURN_VOID(RETVAL);
}

static UInt8 sSiI9134_getData8( IO_Addr_t Addr )
{
    UInt8 Data;

    IO_getData(sIOInst, Addr, 1, &Data);
    RETURN(RETVAL,0);
    return Data;
}

static void sSiI9134_setData16( IO_Addr_t Addr, UInt16 Data )
{
    IO_setData(sIOInst, Addr, 2, &Data);
    RETURN_VOID(RETVAL);
}

static UInt16 sSiI9134_getData16( IO_Addr_t Addr )
{
    UInt16 Data;

    IO_getData(sIOInst, Addr, 2, &Data);
    RETURN(RETVAL,0);
    return Data;
}

static void sSiI9134_setBlock( IO_Addr_t Addr, UInt8 Size, UInt8* pData )
{
    IO_setData(sIOInst, Addr, Size, pData);
    RETURN_VOID(RETVAL);
}

static void sSiI9134_getBlock( IO_Addr_t Addr, UInt8 Size, UInt8* pData )
{
    IO_getData(sIOInst, Addr, Size, pData);
    RETURN_VOID(RETVAL);
}

static void sSiI9134_Dump( void )
{
    UInt16 Addr;
    UInt8  bank;
    UInt8  device = IO_getDevice(sIOInst);
     
    printf("   SiI9134    00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f\n");

    for( bank=0; bank<2; bank++ )
    {
        for( Addr = 0; Addr <= 255; Addr++ )
        {
            if (bank==0)
            {
                if ( Addr%16 == 0 )
                   (device) ?  printf("\n[0x76 0x%0.2X]   ", Addr ) : printf("\n[0x72 0x%0.2X]   ", Addr );
                   
                printf("%0.2X ", dSiI9134_RD8(Addr));
            }
            else
            {
                if ( Addr%16 == 0 )
                   (device) ?  printf("\n[0x7E 0x%0.2X]   ", Addr ) : printf("\n[0x7A 0x%0.2X]   ", Addr );
                    
                printf("%0.2X ", dSiI9134_RD8(0x0100 + Addr));

            }
        }
        printf("\n");
    }
    printf("\n");
}

//-------------------------------------------------------------------
/* the following function is defined but not used */
#if 0
static UInt32 sSiI9134_Get_CTS_Hval( void )
{
    UInt8  temp8 = 0;
    UInt32 temp32 = 0;

    // collect 20-bit value, starting with MSbyte
    temp8 = sSiI9134_getData8( CTS_HVAL3_ADDR );
    temp32 = (temp32 | (UInt32)temp8 ) << 8;
    temp8 = sSiI9134_getData8( CTS_HVAL2_ADDR );
    temp32 = (temp32 | (UInt32)temp8 ) << 8;
    temp8 = sSiI9134_getData8( CTS_HVAL1_ADDR );
    temp32 = (temp32 | (UInt32)temp8 );

    return temp32;
}
#endif

//-------------------------------------------------------------------
static void sSiI9134_Set_N_Sval( UInt32 value )
{
    sACR_N_Sval = value ;
    sSiI9134_setData8( N_SVAL1_ADDR, (UInt8) (sACR_N_Sval & 0x000000ffUL)       );
    sSiI9134_setData8( N_SVAL2_ADDR, (UInt8)((sACR_N_Sval & 0x0000ff00UL) >> 8 ));
    sSiI9134_setData8( N_SVAL3_ADDR, (UInt8)((sACR_N_Sval & 0x000f0000UL) >> 16));
}
//-------------------------------------------------------------------
/* the following function is defined but not used */
#if 0
static UInt32 sSiI9134_Get_N_Sval( void )
{
    return sACR_N_Sval;
}
#endif

/* the following function is defined but not used */
#if 0
static void sSiI9134_ResetMDDC( void )
{
    dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_ABORT);
    dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_CLOCK);
    dSiI9134_WR8(MDDC_MANUAL_ADDR,  0);
}
#endif

static rval_t sSiI9134_setBlockMDDC( MDDC_t* pMDDC, UInt8* pData )
{
    UInt16     Size    = (pMDDC->NBytesMSB<<8) + pMDDC->NBytesLSB;
    Timer_TO_t TimeOut = 0;
    UInt8      Status;

    Timer_setTimeOut(&TimeOut, 100);
    do
    {
        Status = dSiI9134_RD8(MDDC_STATUS_ADDR);

        if( Timer_isTimeOut(TimeOut) )
            return 1;

    } while( Status&BIT_MDDC_ST_IN_PROGR );

    sSiI9134_setBlock(MASTER_BASE+1, sizeof(MDDC_t), (UInt8*)pMDDC);
    dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_CLEAR_FIFO);

    while( !Timer_isTimeOut(TimeOut) )
    {
        UInt8 Cnt = 16-dSiI9134_RD8(MDDC_FIFO_CNT_ADDR);

        if( Cnt < Size )
        {
            sSiI9134_setBlock(MDDC_FIFO_ADDR, Cnt, pData);
            pData += Cnt;
            Size  -= Cnt;
        }
        else
        {
            sSiI9134_setBlock(MDDC_FIFO_ADDR, Size, pData);
            pData += Size;
            Size   = 0;
        }

        Status = dSiI9134_RD8(MDDC_STATUS_ADDR);
        if( !(Status&BIT_MDDC_ST_IN_PROGR) )
        {
            dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_SEQ_WR);
        }

        Status = dSiI9134_RD8(MDDC_STATUS_ADDR);
        if( !(Status&BIT_MDDC_ST_IN_PROGR) )
            return 0;

        if( Status&BIT_MDDC_ST_NO_ACK )
            break;
    }

    dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_ABORT);
    return 1;
}

static rval_t sSiI9134_getBlockMDDC( MDDC_t* pMDDC, UInt8* pData )
{
    UInt16     Size    = (pMDDC->NBytesMSB<<8) + pMDDC->NBytesLSB;
    Timer_TO_t TimeOut = 0;

    sSiI9134_setBlock(MASTER_BASE+1, sizeof(MDDC_t), (UInt8*)pMDDC);
    dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_CLEAR_FIFO);
    dSiI9134_WR8(MDDC_COMMAND_ADDR, MASTER_CMD_SEQ_RD);

    Timer_setTimeOut(&TimeOut, 100);
    do
    {
        UInt8 Cnt = 0;

        while( !Cnt && !Timer_isTimeOut(TimeOut) )
        {
            Cnt = dSiI9134_RD8(MDDC_FIFO_CNT_ADDR);
        }

        sSiI9134_getBlock(MDDC_FIFO_ADDR, Cnt, pData);

        pData += Cnt;
        Size  -= Cnt;
    } while( Size && !Timer_isTimeOut(TimeOut) );

    return (Size) ? (1) : (0);
}

//---------------------------------------------------------------------------
// NOTE:  The following function were taken directly from the Silicon Image's
//        9134 Driver.  They were simply ported to use our IO routine rather
//        the calls that they were using.
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Function Name: SetDeepColor
// Function Description:  This function sets Deep Color
//---------------------------------------------------------------------------
static void sSetDeepColor ( UInt8 bDeepColor ){
    LOG_FUNC_NAME("SiI9134_setDeepColor")
    UInt8 bRegVal, bTmpDeepColor;
    UInt8 bRegVal2;

    bTmpDeepColor = bDeepColor;
    if (bTmpDeepColor == SiI_DeepColor_Off) {
        bDeepColor = SiI_DeepColor_24bit;       // Setup everything as 24bpp but do not turn deep color on
    }

    // VID_ACEN_ADDR
    //  [7:6] - Wide Bus
    //          0b00 = 24 bits
    //          0b01 = 30 bits
    //          0b10 = 36 bits
    bRegVal = (sSiI9134_getData8 ( VID_ACEN_ADDR ) & VID_ACEN_DEEP_COLOR_CLR);
    bRegVal |= (bDeepColor << 6);

    sSiI9134_setData8 ( VID_ACEN_ADDR,  bRegVal );
    LOG_TXT1(("Set Deep Color VID_ACEN_ADDR"));

    // AUDP_TXCTRL_ADDR
    //  [5:3] � PACKET_MODE
    //          0b100 = 24 bits
    //          0b101 = 30 bits
    //          0b110 = 36 bits
    // Set / Clear bit 5 separately below.
    bRegVal = (sSiI9134_getData8 ( AUDP_TXCTRL_ADDR ) & 0xE7);
    bRegVal |= (bDeepColor << 3);

    if (bTmpDeepColor != SiI_DeepColor_Off) {
        bRegVal |= BIT_DEEPCOLOR_EN;
        bRegVal |= 0x20;

 // Enable dithering and set Dither Mode for Deep Color:
        bRegVal2 = (sSiI9134_getData8 ( TX_VID_MODE_ADDR ) & CLR_BITS_7_6_5);
        bRegVal2 |= (bDeepColor << 6);
        bRegVal2 |= BIT_DITHER_EN;
    }
    else {
        bRegVal &= (~BIT_DEEPCOLOR_EN);
        bRegVal &= (~0x20);

        bRegVal2 = (sSiI9134_getData8 ( TX_VID_MODE_ADDR ) & CLR_BITS_7_6_5);    // Disable dithering if not DC
    }

    sSiI9134_setData8 (  AUDP_TXCTRL_ADDR, bRegVal );
    sSiI9134_setData8 (  TX_VID_MODE_ADDR, bRegVal2 );
    LOG_TXT1(("Set Deep Color AUDP_TXCTRL_ADDR"));
    
}


//------------------------------------------------------------------------------
// SiI_TMDS_setup
//------------------------------------------------------------------------------
static UInt8 sSiI_TMDS_setup(UInt8 bVMode)
{
    LOG_FUNC_NAME("SiI_TMDS_setup")
    int idclk_freq, iLowRange, iMidRange1, iMidRange2, iHghRange;
    TCLK_SEL tclk;
    UInt8 bRegVal;
    UInt8 bRegVal2;
    UInt8 nFFRCOUNT, nFFBCOUNT, nFPOSTCOUNT;

    LOG_TXT1(("Start..."));
    //idclk_freq = (int) VModeTables[bVMode].PixClk / 100;
    bVMode = bVMode;
    idclk_freq = (int) (SiI9135_getPixelFrequency() / 100);
        
    bRegVal = sSiI9134_getData8 ( TX_TMDS_CTRL_ADDR ) & 0x60;
    switch (bRegVal) {
        case 0x00: tclk = x0_5; LOG_TXT1(("0.5x tclk")); break;
        default:
        case 0x20: tclk = x1;   LOG_TXT1(("1.0x tclk")); break;
        case 0x40: tclk = x2;   LOG_TXT1(("2.0x tclk")); break;
        case 0x60: tclk = x4;   LOG_TXT1(("4.0x tclk")); break;
    }

    bRegVal = sSiI9134_getData8 ( VID_ACEN_ADDR );
    bRegVal = bRegVal & (~VID_ACEN_DEEP_COLOR_CLR);
    bRegVal = bRegVal >> 6;

    iLowRange = 25;
    switch (bRegVal) {
        case SiI_DeepColor_24bit:
            nFFBCOUNT = 0x03;
            iMidRange1 =  64;
            iMidRange2 = 126;
            iHghRange  = 270;
            break;
        case SiI_DeepColor_30bit:
            nFFBCOUNT = 0x04;
            iMidRange1 =  53;
            iMidRange2 = 104;
            iHghRange  = 203;
            break;
        case SiI_DeepColor_36bit:
            nFFBCOUNT = 0x05;
            iMidRange1 =  44;
            iMidRange2 =  86;
            iHghRange  = 168;
            break;
    }
    // Set FFBCount field in 0x7A:0x83:
    // NOTE: UP TO BUILD 14, nFFBCOUNT value caldulted in the switch statement above was not used.
    // Instead, the code forced it to 0x03 (line 303 below).This line sets it to the calculated value.
    // Line 303 was modified accordingly. Consult DD.
    bRegVal2 = sSiI9134_getData8 ( TX_TMDS_CTRL2_ADDR );
    bRegVal2 &= CLR_BITS_5_4_3;
    bRegVal2 |= (nFFBCOUNT << 3);
    sSiI9134_setData8 ( TX_TMDS_CTRL2_ADDR, bRegVal2 );

    switch (tclk) {
        case x0_5:  nFPOSTCOUNT = 0x07; break;
        case x1:    nFPOSTCOUNT = 0x03; break;
        case x2:    nFPOSTCOUNT = 0x01; break;
        case x4:    nFPOSTCOUNT = 0x00; break;
    }

    // Out of Range
    if ((idclk_freq < iLowRange) || (idclk_freq > iHghRange)) {
        return TMDS_SETUP_FAILED;
    }

    // Blue range
    if ((idclk_freq >= iLowRange) && (idclk_freq <= iMidRange1)) {
        nFFRCOUNT = 0x00;
        sSiI_Mpll_setup(blue);
        sSiI_FApost_setup(blue, idclk_freq, bRegVal);
    }
    else
        // Yellow range
        if ((idclk_freq > iMidRange1) && (idclk_freq <= iMidRange2)) {
            if (tclk == x4) {
                return TMDS_SETUP_FAILED;
            }
            nFFRCOUNT = 0x01;
            nFPOSTCOUNT >>= 1;
            sSiI_Mpll_setup(yellow);
            sSiI_FApost_setup(yellow, idclk_freq, bRegVal);
        }
        else
            // Orange range
            if ((idclk_freq > iMidRange2) && (idclk_freq <= iHghRange)) {
                if ((tclk == x4) || (tclk == x2)) {
                    return TMDS_SETUP_FAILED;
                }
                nFFRCOUNT = 0x03;
                nFPOSTCOUNT >>= 2;
                sSiI_Mpll_setup(orange);
                sSiI_FApost_setup(orange, idclk_freq, bRegVal);
            }

    // TX_SYS_CTRL4_ADDR
    //  [7:5]   reserved
    //  [4:1]   IPLLF = 0x01*
    //  [0]     reserved
    sSiI9134_setData8 (TX_SYS_CTRL4_ADDR, ((sSiI9134_getData8(TX_SYS_CTRL4_ADDR) & 0xE1 ) | (0x01 << 1)));

    // TX_TMDS_CTRL2_ADDR
    //  [7:6]   TPOSTCOUNT
    //  [5:3]   FFBCOUNT = 0x03*

    //  [2:0]   FFRCOUNT*

    sSiI9134_setData8 (TX_TMDS_CTRL2_ADDR, ((sSiI9134_getData8(TX_TMDS_CTRL2_ADDR) & 0xF8) | (nFFRCOUNT)));// Use calculated nFFBCOUNT value rather
                                                                                                               // than 0x03. Value set after the
                                                                                                               // "switch (bRegVal)" statement in this function.
                                                                                                               // Consult DD.
    // TX_TMDS_CTRL3_ADDR
    //  [7]     reserved
    //  [6:3]   ITPLL
    //  [2:0]   FPOSTCOUNT*
    sSiI9134_setData8 (TX_TMDS_CTRL3_ADDR, ((sSiI9134_getData8(TX_TMDS_CTRL3_ADDR) & 0xF8)  | (nFPOSTCOUNT)));

    return TMDS_SETUP_PASSED;
}

//------------------------------------------------------------------------------
// SiI_Mpll_setup
//------------------------------------------------------------------------------
static void sSiI_Mpll_setup(UInt8 MpllSet)
{
    UInt8 itpll, tpostcount, tfrcount;

    itpll = 0x06;
    switch (MpllSet) {
        default:
        case blue:
            tpostcount = 0x02;
            tfrcount   = 0x00;
            break;
        case yellow:
            tpostcount = 0x01;
            tfrcount   = 0x01;
            break;
        case orange:
            tpostcount = 0x00;
            tfrcount   = 0x02;
            break;
    }
    // TX_TMDS_CTRL2_ADDR
    //  [7:6]   TPOSTCOUNT*
    //  [5:3]   FFBCOUNT
    //  [2:0]   FFRCOUNT
    sSiI9134_setData8 (TX_TMDS_CTRL2_ADDR, ((sSiI9134_getData8(TX_TMDS_CTRL2_ADDR) & 0x3F) | (tpostcount << 6)));

    // TX_TMDS_CTRL3_ADDR
    //  [7]     reserved
    //  [6:3]   ITPLL*
    //  [2:0]   FPOSTCOUNT
    sSiI9134_setData8 (TX_TMDS_CTRL3_ADDR, ((sSiI9134_getData8(TX_TMDS_CTRL3_ADDR) & 0x87)  | (itpll << 3)));

    // TX_TMDS_CTRL4_ADDR
    //  [7:2]   reserved
    //  [1:0]   TFRPOSTCOUNT*
    sSiI9134_setData8 (TX_TMDS_CTRL4_ADDR, ((sSiI9134_getData8(TX_TMDS_CTRL4_ADDR) & 0xFC) | (tfrcount)));
}

//------------------------------------------------------------------------------
// SiI_FApost_setup
//------------------------------------------------------------------------------
static void sSiI_FApost_setup(UInt8 RangeSet, int idclk_freq, UInt8 bpp)
{
    UInt8 nFAPOSTCOUNT = 0;
    switch (RangeSet) {
        default:
        case blue:
            switch (bpp) {
                default:
                case SiI_DeepColor_Off:
                case SiI_DeepColor_24bit: if (idclk_freq >= 44) nFAPOSTCOUNT = 1; break;
                case SiI_DeepColor_30bit: if (idclk_freq >= 33) nFAPOSTCOUNT = 1; break;
                case SiI_DeepColor_36bit: if (idclk_freq >= 30) nFAPOSTCOUNT = 1; break;
            }
            break;
        case yellow:
            switch (bpp) {
                default:
                case SiI_DeepColor_Off:
                case SiI_DeepColor_24bit: if (idclk_freq >= 86) nFAPOSTCOUNT = 1; break;
                case SiI_DeepColor_30bit: if (idclk_freq >= 71) nFAPOSTCOUNT = 1; break;
                case SiI_DeepColor_36bit: if (idclk_freq >= 58) nFAPOSTCOUNT = 1; break;
            }
            break;
        case orange:
            switch (bpp) {
                default:
                case SiI_DeepColor_Off:
                case SiI_DeepColor_24bit: if (idclk_freq >= 168) nFAPOSTCOUNT = 1; break;
                case SiI_DeepColor_30bit: if (idclk_freq >= 139) nFAPOSTCOUNT = 1; break;
                case SiI_DeepColor_36bit: if (idclk_freq >= 114) nFAPOSTCOUNT = 1; break;
            }
            break;
    }
    // TX_TMDS_CCTRL_ADDR
    //  [7:6]   reserved
    //  [5]     FAPOSTCOUNT*
    //  [4:0]   reserved
    sSiI9134_setData8 (TX_TMDS_CCTRL_ADDR, ((sSiI9134_getData8(TX_TMDS_CCTRL_ADDR) & 0xDF) | (nFAPOSTCOUNT << 5)));
}

#define GetVSyncInt()               ( sSiI9134_getData8( HDMI_INT2_ADDR) & BIT_INT_VSYNC )
#define ClearVSyncInt()             ( sSiI9134_setData8( HDMI_INT2_ADDR, BIT_INT_VSYNC ))

//------------------------------------------------------------
static Bool sWaitNewVSync( void )
{
    UInt8 TimeOutCount = 255;
    Bool Result = FALSE;
    
    ClearVSyncInt();
    while((TimeOutCount--)&&GetVSyncInt());
    if(TimeOutCount)
        Result = TRUE;
    return Result;
}

//-------------------------------------------------------------------------------
static void sSendCP_Packet(UInt8 On)
{
    UInt8 RegVal, TimeOutCount = 64;

    RegVal = sSiI9134_getData8( PB_CTRL2_ADDR );
    sSiI9134_setData8(PB_CTRL2_ADDR, RegVal & (~BIT_CP_REPEAT));
    if(On)
        sSiI9134_setData8( CP_IF_ADDR, BIT_CP_AVI_MUTE_SET);
    else
        sSiI9134_setData8( CP_IF_ADDR, BIT_CP_AVI_MUTE_CLEAR);

    while(TimeOutCount--){
        if( !(sSiI9134_getData8( PB_CTRL2_ADDR) & BIT_CP_REPEAT))
            break;
    }
    if(TimeOutCount)
        sSiI9134_setData8(PB_CTRL2_ADDR, RegVal | BIT_CP_ENABLE | BIT_CP_REPEAT);

}
//-------------------------------------------------------------

//static void sTXAudio(UInt8 On) 
//{
//    UInt8 RegVal;
//
//    RegVal = sSiI9134_getData8(AUD_MODE_ADDR);
//    if(On)
//        sSiI9134_setData8(AUD_MODE_ADDR, RegVal | BIT_AUDIO_EN);
//    else
//        sSiI9134_setData8(AUD_MODE_ADDR, RegVal & (~BIT_AUDIO_EN));
//}

//---------------------------------------------------------------
//static void sSetEncryption(UInt8 OnOff)
//{
//    UInt8 RegVal;
//
//    RegVal = sSiI9134_getData8(HDCP_CNTRL_ADDR);
//    if (OnOff)
//        sSiI9134_setData8(HDCP_CNTRL_ADDR, RegVal | BIT_ENC_EN);
//    else
//        sSiI9134_setData8(HDCP_CNTRL_ADDR, RegVal & ~BIT_ENC_EN);
//}

//-------------------------------------------------------------------
static void sAssertHDMITX_SWReset(UInt8 SoftReset)
{
  UInt8 RegVal;

     RegVal = sSiI9134_getData8( TX_SWRST_ADDR );
     RegVal |= SoftReset;
     sSiI9134_setData8( TX_SWRST_ADDR, SoftReset);
}
//-------------------------------------------------------------------
static void sReleaseHDMITX_SWReset( UInt8 SoftReset )
{
  UInt8 RegVal;

     RegVal = sSiI9134_getData8( TX_SWRST_ADDR );
     RegVal &= (~SoftReset);
     sSiI9134_setData8( TX_SWRST_ADDR, 0);
}
//-------------------------------------------------------------------
static void sSW_ResetHDMITX(void){
      UInt8 TimeOut = 255;

      while ( !siiIsTClockStable() && TimeOut-- ) {};         // wait for input pixel clock to stabilze
      if (TimeOut)
      {
         sAssertHDMITX_SWReset(BIT_TX_SW_RST | BIT_TX_FIFO_RST);
         System_setMicroDelay( 1000 );
         sReleaseHDMITX_SWReset(BIT_TX_SW_RST | BIT_TX_FIFO_RST);
         System_setMicroDelay( 64000 ); // allow TCLK (sent to Rx across the HDMS link) to stabilize
      }
}


/************************************************************************/
/*      Local Functions                                                 */
/************************************************************************/
static void sSiI9134_UpdateColorSpaceConversion( void )
{
    dSiI9134_CLR8(VID_MODE_ADDR, 0x08); /* No YCbCr to RGB */
    dSiI9134_CLR8(VID_MODE_ADDR, 0x04); /* No 422 to 444 */

    switch( sInpClrSpc )
    {
        case eSiI9134_ClrSpc_RGB444 :
            switch( sOutClrSpc )
            {
                case eSiI9134_ClrSpc_YUV422 :
                    assert(0);
                    break;

                case eSiI9134_ClrSpc_YUV444 :
                    assert(0);
                    break;
            }
            break;

        case eSiI9134_ClrSpc_YUV422 :
            switch( sOutClrSpc )
            {
                case eSiI9134_ClrSpc_RGB444 :
                    dSiI9134_SET8(VID_MODE_ADDR, 0x08); /* YCbCr to RGB */
                    dSiI9134_SET8(VID_MODE_ADDR, 0x04); /* 422 to 444 */
                    break;

                case eSiI9134_ClrSpc_YUV444 :
                    dSiI9134_SET8(VID_MODE_ADDR, 0x04); /* 422 to 444 */
                    break;
            }
            break;

        case eSiI9134_ClrSpc_YUV444 :
            switch( sOutClrSpc )
            {
                case eSiI9134_ClrSpc_RGB444 :
                    dSiI9134_SET8(VID_MODE_ADDR, 0x08); /* YCbCr to RGB */
                    break;

                case eSiI9134_ClrSpc_YUV422 :
                    assert(0);
                    break;
            }
            break;
    }
}

static Bool sSiI9134_isHotPlug( void )
{
    return (dSiI9134_GET8(TX_SYS_STATUS_ADDR, 0x02)) ? (TRUE) : (FALSE);
}

static Bool sSiI9134_isHotPlugEvent( void )
{
    Bool bHotPlug = (dSiI9134_GET8(0x71, 0x40)) ? (TRUE) : (FALSE);

    dSiI9134_WR8(0x71, 0x40);
    return bHotPlug;
}

static void sSiI9134_HPHandler( void )
{
    IO_Dev_t DevTot = sDevTot;

    while( DevTot-- )
    {
        IO_setDevice(sIOInst, DevTot);

        if( sSiI9134_isHotPlugEvent() )
        {
            CBFunc_CallFunctions(sHotPlugCBInst[DevTot]);
        }
    }
}

/** END of File *********************************************************/
